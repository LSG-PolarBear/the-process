import requests
import uuid
import os
import json
import time
import datetime

C2_8301 = "http://103.45.66.92:8301"
HEADERS = {
    "User-Agent": "Mozilla/5.0",
    "Content-Type": "application/json; charset=utf-8"
}

desktop_path = os.path.join(os.path.expanduser("~"), "Desktop")
if not os.path.exists(desktop_path):
    
    desktop_path = os.path.join(os.environ['USERPROFILE'], "Desktop")

folder_name = f"Steam骗局证据_{datetime.datetime.now().strftime('%H%M%S')}"
OUTPUT_DIR = os.path.join(desktop_path, folder_name)

os.makedirs(OUTPUT_DIR, exist_ok=True)
print(f"证据将保存在桌面的文件夹中: {OUTPUT_DIR}")

def monitor():
    print("\n开始")
    print("脚本自动运行中\n")
    
    while True:
        fake_mid = str(uuid.uuid4())
        payload = json.dumps({"mid": fake_mid, "ch": "ali"})
        try:
            res = requests.post(f"{C2_8301}/code/acquire", data=payload, headers=HEADERS, timeout=10)
            data = res.json()
            
            if data.get("ok") is True:
                print(f"\n抓到新账号: {data}")
                
                
                img_url = f"{C2_8301}/code/img?mid={fake_mid}&ch=ali&t={int(time.time()*1000)}"
                img_res = requests.get(img_url, headers=HEADERS, timeout=10)
                if img_res.status_code == 200 and len(img_res.content) > 100:
                    filename = os.path.join(OUTPUT_DIR, f"单码_Alipay_QR_{fake_mid}.png")
                    with open(filename, "wb") as f:
                        f.write(img_res.content)
                    print(f"    [+] 证据已保存: {filename}")
                    
                
                g_payload = json.dumps({"mid": fake_mid, "ch": "ali", "exclude": ""})
                g_res = requests.post(f"{C2_8301}/code/group/acquire", data=g_payload, headers=HEADERS, timeout=10)
                g_data = g_res.json()
                if g_data.get("ok") is True:
                    print(f"码抓到了: {g_data}")
                    for i in range(1, 4):
                        g_img = requests.get(f"{C2_8301}/code/group/img?mid={fake_mid}&idx={i}", headers=HEADERS, timeout=10)
                        if g_img.status_code == 200 and len(g_img.content) > 100:
                            g_filename = os.path.join(OUTPUT_DIR, f"连环套_{i}_Alipay_QR_{fake_mid}.png")
                            with open(g_filename, "wb") as f:
                                f.write(g_img.content)
                            print(f"    [+] 证据保存: {g_filename}")
                
                print("\n继续监控")
            else:
                
                print(f"[{time.strftime('%H:%M:%S')}] 暂无可用账号 (reason: {data.get('reason')})", end='\r')
                
        except Exception as e:
            print(f"\n请求异常: {e}")
            
        
        time.sleep(30)

if __name__ == "__main__":
    monitor()